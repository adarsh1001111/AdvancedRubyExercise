require_relative '..\eval_story\my_object_store.rb'

class Play
  include MyObjectStore

  attr_accessor :age, :fname, :email, :lname, :name, :bio, :password, :registration_number, :points

  validates :fname, :email, presence: true
  validates :age, range: [18, 60]
  validates :email, format: { with: /\A[a-zA-Z]+\z/ }
  validates :fname, length: { minimum: 2 }
  validates :bio, length: { maximum: 500 }
  validates :password, length: { in: 6..20 }
  validates :registration_number, length: { is: 6 }
  validates :points, numericality: true
  validates :email, uniqueness: true
  validates :something , somethinggg: true

  def validate
    true
  end
end

p Play.constants
p1 = Play.new
p1.fname = 'abc'
p1.email = 'adarsh'
p1.age = 19
p1.points = 20
p1.password = 'adarsh'
p1.registration_number = 1
p p1.valid?
p1.save # ye save hona chahiye
p p1.errors
p1.registration_number = 123456
p p1.valid?
p1.save
p p1.errors # should log empty hash

p2 = Play.new
p2.fname = 'def' 
p2.email = 'adarsh' # uniquess fail krna chahiye
p2.age = 30
p2.points = 'abc'   # not numerical
p2.save # password fail and registration no. fail, points bhi fail
p p2.errors # p2 ke logged errors return hone chahiye

puts "Validators: #{Play.validators}" # rturn all the validators defined on the reciever class
puts "Validations: #{Play.validations}" # return all attribute validation hash like {fname: [ { type: presence, rule: true }]}
puts "Count: #{Play.count}" # work krna chahiye even count is not defined , so Using Enumerable for Play
puts "Find by fname('abc'): #{Play.find_by_fname('abc')}" # find_by_attr defines when attr_accessor :attr runs for that attr
