module MyObjectStore
  require_relative '..\eval_story\require_all_validators.rb'
  require_relative '..\eval_story\custom_errors\no_validation_error.rb'

  def valid?
    validate_all
  end

  def save
    if valid?
      self.class.instance_variable_get(:@container) << self
      puts "#{self} saved successfully"
      @logged_errors.clear
      true
    else
      puts "couldn't save #{self}"
      false
    end
  end

  def errors
    (@logged_errors || {}).dup # duplicAted so that bahar se user can't modify this
  end

  private

  def log_error(attr, msg)
    @logged_errors ||= {}
    (@logged_errors[attr] ||= []) << msg
  end


  def self.included(klass)
    klass.extend ClassMethods
    klass.instance_variable_set(:@container, [])
    klass.instance_variable_set(:@validations, Hash.new { |h, k| h[k] = [] })
    klass.instance_variable_set(:@validators, Set.new)
  end
  
  def get_validator_class(type)
    MyObjectStore.const_get("#{type.to_s.capitalize}Validator")
  end
  
  def validate
    true
  end

  def validate_all
    can_be_saved = true

    unless validate
      can_be_saved = false
      log_error(:custom_validation_method, "returned false")
    end

    self.class.instance_variable_get(:@validations).each do |attr, validations|
      validations.each do |validation|
        type = validation[:type]
        validator_class = get_validator_class(type)
        validator = validator_class.new

        unless validator.validate(self, attr, validation[:rule])
          log_error(attr, "#{attr} failed #{type} validation")
          can_be_saved = false
        end
      end
    end
    can_be_saved
  end

  module ClassMethods
    include Enumerable

    def each
      @container.each{ |saved_obj| yield saved_obj }
    end

    def attr_accessor(*attrs)
      super
      attrs.each do |attr|
        define_singleton_method("find_by_#{attr}") do |val|
          @container.select { |obj| obj.instance_variable_get("@#{attr}") == val }
        end
      end
    end

    def validates(*attrs, **options)
      options.each do |type, rule|
        klass_name = "#{type.to_s.capitalize}Validator"
        raise NoValidationError, type unless MyObjectStore.const_defined?(klass_name)

        @validators << MyObjectStore.const_get(klass_name)
        attrs.each do |attr|
          @validations[attr] << { type: type, rule: rule }
        end
      end
    rescue NoValidationError => e
      p e.message 
    end

    def validators
      @validators.to_a
    end

    def validations
      @validations.dup #taaki koi user can't modify this bahar se
    end
  end
end