class NoValidationError < StandardError
  def initialize(type)
    super("no such #{type} validation exist")
  end
end