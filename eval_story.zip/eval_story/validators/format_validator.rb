class MyObjectStore::FormatValidator
  def validate(obj, attr, rule)
    val = obj.instance_variable_get("@#{attr}")
    val && rule[:with] && val =~ rule[:with]
  end
end