class MyObjectStore::NumericalityValidator
  def validate(obj, attr, rule)
    val = obj.instance_variable_get("@#{attr}")
    val.is_a?(Numeric)
  end
end