class MyObjectStore::UniquenessValidator
  def validate(obj, attr, rule)
    container = obj.class.instance_variable_get(:@container)
    val = obj.instance_variable_get("@#{attr}")
    !container.any? { |saved_obj| saved_obj.instance_variable_get("@#{attr}") == val }
  end
end