class MyObjectStore::RangeValidator
  def validate(obj, attr, rule)
          val = obj.instance_variable_get("@#{attr}")
          val && (val >= rule[0] && val <= rule[1])
  end
end