class MyObjectStore::LengthValidator
  def validate(obj, attr, rule)
    val_str = obj.instance_variable_get("@#{attr}").to_s
    return true unless rule.is_a?(Hash)

    if rule[:minimum] && val_str.length < rule[:minimum]
      false
    elsif rule[:maximum] && val_str.length > rule[:maximum]
      false
    elsif rule[:in] && !rule[:in].include?(val_str.length)
      false
    elsif rule[:is] && val_str.length != rule[:is]
      false
    else
      true
    end
  end
end