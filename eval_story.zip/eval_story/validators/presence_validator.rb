class MyObjectStore::PresenceValidator
  def validate(obj, attr, rule)
    val = obj.instance_variable_get("@#{attr}")
    rule ? !val.nil? && !(val.respond_to?(:empty?) && val.empty?) : val.nil?
  end
end